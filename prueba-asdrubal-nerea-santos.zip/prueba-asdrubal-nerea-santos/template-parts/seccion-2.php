<section class="contenido">
    <img src="<?php echo get_template_directory_uri(); ?>/img/icono-nosotros2.png" alt="icono de nosotros">
    <h3 class="titulo-seccion">Servicios que podemos ofrecerte</h3>
    <ul class="servicios">
        <li class="servicios-item">Desarrollos Web</li>
        <li class="servicios-item">Diseño Web</li>
        <li class="servicios-item">SEO</li>
        <li class="servicios-item">SEM</li>
    </ul>
    <button class="leer-mas">Leer más</button>
</section>