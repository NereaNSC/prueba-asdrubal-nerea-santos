<section class="contenido">
    <img src="<?php echo get_template_directory_uri(); ?>/img/icono-cliente1.png" alt="icono de nosotros">
    <h3 class="titulo-seccion">Bienvenido a mi Sitio Web</h3>
    <p class="descripcion-seccion">Aliquam sit amet viverra sapien. Vivamus laoreet porttitor
        purus, et rhoncus nisi. Quisque dictum vel purus id condimentum.</p>
    <button class="leer-mas">Leer más</button>
</section>